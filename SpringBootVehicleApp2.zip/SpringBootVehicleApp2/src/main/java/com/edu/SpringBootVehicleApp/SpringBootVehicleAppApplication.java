package com.edu.SpringBootVehicleApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootVehicleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootVehicleAppApplication.class, args);
	}

}
