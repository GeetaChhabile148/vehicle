package com.edu.SpringBootVehicleApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootVehicleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
